<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" type="text/php" href="index.php">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 20px;
            margin: 0px;
        }
        header h1{
            padding: 10px;
        }

        nav {
            background-color: #2980b9;
            padding: 10px;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #ecf0f1;
        }

        footer {
            background-color: #34495e;
            color: #ecf0f1;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            margin: 0px;
        }
        .bgimg {
            background-image: url('2.jpeg'); /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #000000;

        }
        section{
            background-color: #f8f8f8a8;
            margin: 30px;
        }
    </style>

    <title>Contact Me</title>
</head>
<body>
    <header>
        <h1>Contact Me</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home<z/a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="display.php">Display Data</a></li>
            </ul>
        </nav>

    </header>

    <section>
        <form action="process_contact.php" method="POST">
        <div class="formgroup">
            <label for="name">Name:</label>
            <input class="form-control" type="name" id="name" name="name" required>
        </div>
        <div class="formgroup">
            <label for="email">Email:</label>
            <input class="form-control" type="email" id="email" name="email" required>
        </div>
        <div class="formgroup">
            <label for="message">Message:</label>
            <textarea class="form-control" type="text" id="message" name="message" rows="4" required></textarea>
        </div>
            <input type="submit" name="submit" id="submit" class="btn btn-dark">
        </form>
    </section>

    <footer>
        <p>&copy; 2023 Rita</p>
    </footer>
</body>
</html>
