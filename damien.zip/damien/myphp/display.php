<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <title>Display Data</title>
    <style type="text/css">
         body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 20px;
            margin: 0px;
        }
        header h1{
            padding: 10px;
        }

        nav {
            background-color: #2980b9;
            padding: 10px;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #ecf0f1;
        }
        
        footer {
            background-color: #34495e;
            color: #ecf0f1;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            margin: 0px;
        }

        .bgimg {
            background-image: url('contactbg.jpeg'); /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #000000;

        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: #00000080;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
            color: #fff;
        }

        th {
            background-color: #333;
            color: white;
            font-family: Arial Black;
        }
    </style>
</head>
<body>
    <header>
        <h1>Display Data</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="display.php">Display Data</a></li>
            </ul>
        </nav>

    </header>
    <div class="bgimg">
    <section>
        <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "php";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Retrieve data from the database
            $sql = "SELECT * FROM user";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                echo "<h2>Contact Form Data</h2>";
                echo "<table border='1'>";
                echo "<tr><th>Name</th><th>Email</th><th>Message</th></tr>";
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . $row["name"] . "</td>";
                    echo "<td>" . $row["email"] . "</td>";
                    echo "<td>" . $row["message"] . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "No data found";
            }

            $conn->close();
            ?>
        <!-- Your displayed data here -->
        <div>.</div>
        <div>.</div>
    </section>

    <footer>
        <p>&copy; 2023 Rita</p>
    </footer>
</div>s
</body>
</html>
