<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="style.css"> <!-- Your custom styles -->
    <title>Contact Me</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

       

        .bgimg {
            background-image: url('contact.jpeg'); /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #000000;

        }
        header {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 20px;
            margin: 0px;
        }
        header h1{
            padding: 10px;
        }

        nav {
            background-color: #2980b9;
            padding: 10px;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #ecf0f1;
        }
        
        footer {
            background-color: #34495e;
            color: #ecf0f1;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            margin: 0px;
        }

    </style>
</head>
<body>
    <header>
         <h1>Thanks for contacting us!!!</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="display.php">Display Data</a></li>
            </ul>
        </nav>
    </header>


    <div class="bgimg">
        <?php
    error_reporting(E_ALL);
ini_set('display_errors', 'On');

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $conn = mysqli_connect('localhost', 'root', '', 'php') or die("Connection failed: " . mysqli_connect_error());

    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    $sql = "INSERT INTO `user` (`name`, `email`, `message`) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $sql);

    if (!$stmt) {
        // Check for prepare error
        die('Statement preparation failed: ' . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "sss", $name, $email, $message);

    if (mysqli_stmt_execute($stmt)) {
        echo "<h3 style='color: black; background-color='white'; margin:30px; padding:50px;'>Thank you for contacting us. Please  <a href='index.php'>click here </a>to return to main page</h3>";
    } else {
        // Check for execution error
        echo 'Error occurred during execution: ' . mysqli_stmt_error($stmt);
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);
}
?>
    </div>

    <footer>
        <p>&copy; 2023 Rita</p>
    </footer>
</body>
</html>
