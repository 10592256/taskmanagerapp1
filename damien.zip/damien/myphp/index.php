
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="style.css">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #2c3e50;
            color: #fff;
            text-align: center;
            padding: 20px;
            margin: 0px;
        }
        header h1{
            padding: 10px;
        }

        nav {
            background-color: #2980b9;
            padding: 10px;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav a {
            text-decoration: none;
            color: #fff;
            font-weight: bold;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        nav a:hover {
            color: #ecf0f1;
        }

        .welcome-section {
            text-align: center;
            padding: 50px;
            color: #333;
        }

        .welcome-section h2 {
            color: #3498db;
        }

        .welcome-section p {
            margin: 20px 0;
        }

        .welcome-section img {
            max-width: 100%;
            height: auto;
            margin-top: 20px; /* Add some space between text and image */
        }

        footer {
            background-color: #34495e;
            color: #ecf0f1;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
            text-align: center;
            margin: 0px;
        }
        .bgimg {
            background-image: url('2.jpeg'); /* Replace with the path to your background image */
            background-size: cover;
            background-position: center;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
            color: #000000;

        }
        section{
            background-color: #f8f8f8a8;
            margin: 30px;
        }
    </style>

    <title>Your Portfolio</title>
</head>
<body>
    <header>
        <h1>Welcome to My Portfolio</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="display.php">Display Data</a></li>
            </ul>
        </nav>
    </header>
    <div class="bgimg">

    <section class="welcome-section">
        <h2>Hello, I'm Bolortuya </h2>
        <p>
            I am a passionate web developer dedicated to creating engaging and user-friendly websites.
        </p>
        <p>
            Explore my portfolio to discover some of my projects, and feel free to reach out if you have any inquiries or exciting opportunities!
        </p>
        
    </section>
</div>
    <footer>
        <p>&copy; 2023 Rita</p>
    </footer>

    
</body>
</html>
